package com.mygdx.game.characters;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.mygdx.game.MyGdxGame;

public class Bird {
    static  int x, y;

    int width, height;

    float speed;

    int jumpHeight;
    final int maxHeightOfJump = 200;
    boolean jump;

    Texture texture;

    int frameCounter;
    Texture[] framesArray;

    public Bird(int x, int y, int speed, int width, int height){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = speed;

        frameCounter = 0;
        framesArray = new Texture[]{
                new Texture("bird0.png"),
                new Texture("bird1.png"),
                new Texture("bird2.png"),
                new Texture("bird1.png"),
        };
    }

   public void onClick(){
        jump = true;
        jumpHeight = maxHeightOfJump + y;
    }


    public void fly() {

        if (y >= jumpHeight) {
            jump = false;
        }

        if (jump) {
            y += speed;
        } else {
            y -= speed/2;
        }
    }

    public void speedBoost() {
       speed += 0.0001;
    }

    public boolean isInField() {
        if (y + height < 0) return false;
        if (y > MyGdxGame.SCR_HEIGHT) return false;
        return true;
    }

    public void draw(Batch batch) {
        int frameMultiplier = 10;
        batch.draw(framesArray[frameCounter / frameMultiplier], x, y, width, height);
        if (frameCounter++ == framesArray.length * frameMultiplier - 1) frameCounter = 0;
    }

    public void dispose() {
        texture.dispose();
    }


}
