package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.screens.ScreenGame;
import com.mygdx.game.screens.ScreenRestart;
import com.mygdx.game.screens.ScreenStart;

public class MyGdxGame extends Game {
	public SpriteBatch batch;
	public OrthographicCamera camera;

	public static final int SCR_WIDTH = 1280, SCR_HEIGHT = 720;

	public ScreenGame ScreenGame;
	public ScreenRestart screenRestart;
	public ScreenStart ScreenStart;


	@Override
	public void create() {
		batch = new SpriteBatch();
		camera = new OrthographicCamera();
		camera.setToOrtho(false, SCR_WIDTH, SCR_HEIGHT);

		ScreenStart = new ScreenStart(this);
		ScreenGame = new ScreenGame(this);
		screenRestart = new ScreenRestart(this);
		setScreen(ScreenStart);
	}

	@Override
	public void dispose() {
		batch.dispose();
	}
}