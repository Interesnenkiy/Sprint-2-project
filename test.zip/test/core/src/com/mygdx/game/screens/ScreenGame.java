package com.mygdx.game.screens;



import static com.mygdx.game.MyGdxGame.SCR_HEIGHT;
import static com.mygdx.game.MyGdxGame.SCR_WIDTH;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.utils.ScreenUtils;


import com.mygdx.game.characters.Bird;
import com.mygdx.game.characters.Tube;
import com.mygdx.game.components.MovingBackground;
import com.mygdx.game.components.PointCounter;
import com.mygdx.game.MyGdxGame;

public class ScreenGame implements Screen {

        final int pointCounterMarginTop = 60;
        final int pointCounterMarginRight = 400;

        MyGdxGame myGdxGame;

        Bird bird;
        PointCounter pointCounter;
        MovingBackground background;

        int tubeCount = 3;
        Tube[] tubes;

        int gamePoints;
        boolean isGameOver;

        public ScreenGame(MyGdxGame myGdxGame) {
            this.myGdxGame = myGdxGame;

            initTubes();
            background = new MovingBackground("game_bg.png");
            bird = new Bird(20, SCR_HEIGHT / 2, 10, 125, 100);
            pointCounter = new PointCounter(SCR_WIDTH - pointCounterMarginRight, SCR_HEIGHT - pointCounterMarginTop);
        }


        @Override
        public void show() {
            gamePoints = 0;
            isGameOver = false;
            initTubes();
        }

        @Override
        public void render(float delta) {

            if (isGameOver) {

                bird = new Bird(20, SCR_HEIGHT / 2, 10, 100, 80);
                myGdxGame.screenRestart.gamePoints = gamePoints;
                myGdxGame.setScreen(myGdxGame.screenRestart);
            }

            if (Gdx.input.justTouched()) {
                bird.onClick();
            }

            background.move();
            bird.fly();
            if (!bird.isInField()) {
                System.out.println("not in field");
                isGameOver = true;
            }

            for (Tube tube : tubes) {
                tube.move();
                if (tube.isHit(bird)) {
                    isGameOver = true;
                    System.out.println("hit");
                } else if (tube.needAddPoint(bird)) {
                    gamePoints += 1;
                    tube.setPointReceived();
                    System.out.println(gamePoints);
                }
            }
            if (gamePoints>5){
                bird.speedBoost();
            }







            ScreenUtils.clear(1, 0, 0, 1);
            myGdxGame.camera.update();
            myGdxGame.batch.setProjectionMatrix(myGdxGame.camera.combined);
            myGdxGame.batch.begin();

            background.draw(myGdxGame.batch);
            bird.draw(myGdxGame.batch);
            for (Tube tube : tubes) tube.draw(myGdxGame.batch);
            pointCounter.draw(myGdxGame.batch, gamePoints);

            myGdxGame.batch.end();
        }

        @Override
        public void resize(int width, int height) {

        }

        @Override
        public void pause() {

        }

        @Override
        public void resume() {

        }

        @Override
        public void hide() {

        }

        @Override
        public void dispose() {
            bird.dispose();
            background.dispose();
            pointCounter.dispose();
            for (int i = 0; i < tubeCount; i++) {
                tubes[i].dispose();
            }
        }

        void initTubes() {
            tubes = new Tube[tubeCount];
            for (int i = 0; i < tubeCount; i++) {
                tubes[i] = new Tube(tubeCount, i);
            }
        }

    }
